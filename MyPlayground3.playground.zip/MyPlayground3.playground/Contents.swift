//: Playground - noun: a place where people can play

import UIKit

// 1
let Strings = "Hello, World"
for i in Strings.characters.suffix(Strings.characters.count/2)
{
    print(String(i).uppercased(), terminator: "|")
}

// 2
let transactions = [560.0, 321.5, 190.0, 672.8, 1190.0, 450.0]
var sum:Double = 1
for transaction in transactions {
    if (transaction > 500 && transaction < 1000) {
        sum *= transaction
    }
}
print (sum)

// 3
var mul = 0.0
for transaction in transactions{
    if transaction > 350 && transaction < 600{
        print(transaction + 100)
    }
    else if transaction > 900{
        print(transaction - 100)
    }
    else{
        mul = transaction * transaction
    }
}

// 4
let testArray = ["rrr","eee","kkk","aaa","ccc","ddd"]
var resultArray = [String]()
for i in 0..<6{
    for j in 1..<6 {
        
        if(i == testArray.count/2){
            
        }
        else{
            if testArray[i] < testArray[j]{
                resultArray.append(testArray[j])
            }
        }
    }
    if resultArray.count == testArray.count{
        for item in resultArray{
            if item > "ccc"{
                print(item)
            }
        }
    }
}

// 5
let classA : [String:Int] = ["Abby": 83, "Rebeca":31, "Kevin":90, "Alex":42, "Kitten": 100, "Lorry": 24]
let classB : [String:Int] = ["Darin": 74, "Sidney":13, "Rosa":19, "Felix":7, "Leslie": 23, "Louise": 75, "Leigh": 50]
let classC : [String:Int] = ["Kathleen": 83, "Homer":63, "Peter":89, "Wallace":99, "Tommy": 76, "Jeffery": 9, "Diana": 40, "Rickey":33]
let classD : [String:Int] = ["Jaime": 90, "Anne":76, "Samantha":64, "Lorenzo":29, "Tracy": 76, "Irene": 9, "Phillip": 40, "Jimmy": 93, "Simon": 49]


var allClasses : [[String:Int]] = [classA, classB, classC, classD]

var giftedStudents: [String:Int] = [:]
var selectedStudentsScore : [Int] = []


for oneClass in allClasses {
    for student in oneClass {
        if student.value >= 50 {
            giftedStudents.updateValue(student.value, forKey: student.key)
        }
    }
    for student in giftedStudents {
        if(student.key.characters.count > 6) {
            selectedStudentsScore += [student.value]
        }
    }
}

print(selectedStudentsScore)